
import os
from tkinter import Tk, Label, Entry, Button, StringVar, Radiobutton, messagebox

def launch_gui():
    print("GUI launching…")
    root = Tk()
    root.title("Playlist Archiver – Layer 1 Test")
    root.geometry("540x360")
    root.configure(bg="#000000")

    # Simple styles
    sty_label = {"bg": "#000000", "fg": "#DFFF00", "font": ("Arial", 11)}
    entry_style = {"bg": "#1a1a1a", "fg": "#DFFF00", "insertbackground": "#DFFF00", "width": 62,
                   "highlightbackground": "#DFFF00"}
    btn_style = {"bg": "#1a1a1a", "fg": "#DFFF00", "activebackground": "#333333", "activeforeground": "#DFFF00",
                 "relief": "raised", "bd": 2}
    radio_style = {"bg": "#000000", "fg": "#DFFF00", "selectcolor": "#1a1a1a", "activebackground": "#000000"}

    Label(root, text="paste Spotify / YouTube / SoundCloud playlist URL:", **sty_label).pack(pady=6)
    Entry(root, **entry_style).pack(pady=4)

    # mode selector
    mode_var = StringVar(value="Clean")
    Label(root, text="select processing mode:", **sty_label).pack(pady=(8, 0))
    Radiobutton(root, text="Clean Tag", variable=mode_var, value="Clean", **radio_style).pack()
    Radiobutton(root, text="DJ Prep (BPM/key + XML)", variable=mode_var, value="DJ", **radio_style).pack()

    # codec selector
    codec_var = StringVar(value="flac")
    Label(root, text="choose audio format:", **sty_label).pack(pady=(10, 0))
    Radiobutton(root, text="FLAC (hi‑res)", variable=codec_var, value="flac", **radio_style).pack()
    Radiobutton(root, text="MP3 (backup)", variable=codec_var, value="mp3", **radio_style).pack()

    Button(root, text="download & archive", command=lambda: messagebox.showinfo("info", "simulated download"), **btn_style).pack(pady=8)
    Button(root, text="run watchlist sync", command=lambda: messagebox.showinfo("info", "simulated sync"), **btn_style).pack(pady=2)

    root.mainloop()

if __name__ == "__main__":
    launch_gui()
