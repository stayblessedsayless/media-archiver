
from tkinter import Tk, Label, Entry, Button

def launch_gui():
    print("GUI launching…")
    root = Tk()
    root.title("Debug Archiver")
    root.geometry("300x150")
    Label(root, text="If you see this, GUI is working.").pack(pady=20)
    Entry(root).pack(pady=10)
    Button(root, text="Exit", command=root.destroy).pack(pady=10)
    root.mainloop()

if __name__ == "__main__":
    launch_gui()
